# Copyright (c) OpenMMLab. All rights reserved.
# flake8: noqa
import warnings

from .formatting import *

warnings.warn('DeprecationWarning: mmdet.datasets.pipelines.formating will be '
              'deprecated, please replace it with '
              'mmdet.datasets.pipelines.formatting.')
